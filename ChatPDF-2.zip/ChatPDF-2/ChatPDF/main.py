import os
from langchain.document_loaders import PyPDFLoader
from langchain.vectorstores import Chroma
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.document_loaders import UnstructuredPDFLoader, PyPDFDirectoryLoader
from langchain.llms import OpenAI
from langchain.chains.question_answering import load_qa_chain

#env = os.environ.copy()
#print(env)

os.environ["OPENAI_API_KEY"] = "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"

# Replace book.pdf with any pdf of your choice
# loader = UnstructuredPDFLoader("text1.pdf")
loader = PyPDFDirectoryLoader('./pdf/')
pages = loader.load_and_split()
# print(pages)
embeddings = OpenAIEmbeddings(openai_api_key='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')
docsearch = Chroma.from_documents(pages, embeddings).as_retriever()


class PDF_CHAT():
  def getAnswer(self, query):
    # for query in ["計算機基本結構五個單元中，何者負責比較資料大小", "我們將電腦分成第一代、第二代、第三代、第四代等等，請問劃分的依據為何?",
    # "下列何者不是每一個作業系統都會具備的功能? (A)作業系統(OS) (B)隨機存取記憶體(RAM) (C)中央處理單元(CPU) (D)系統管理員(Administrator)"]:
    print("Q: ", query)
    docs = docsearch.get_relevant_documents(query)
    chain = load_qa_chain(OpenAI(temperature=0), chain_type="stuff")
    output = chain.run(input_documents=docs, question=query)
    print("Ans: ", output)
    print("=============================================================================")
    return output