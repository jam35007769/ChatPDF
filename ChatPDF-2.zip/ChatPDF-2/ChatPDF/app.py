from flask import Flask, request
import json
from flask_cors import CORS
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import *
from main import PDF_CHAT


app = Flask(
  __name__,
  static_folder='public',
  static_url_path='/'
)

CORS(app)
pdf_caht = PDF_CHAT()

# 此處換成你自己的 token_access
line_bot_api = LineBotApi('x80e/m9ajODmpSZgBL4h92wo0VBkKr9yyIMzmXsg9oVqDeqag2mCUHu1O3kEJ4Qj2FCc7d6shdvFZN1txFKia7iyBlHOhHl/aWCYNZfEcRpG3EluAmIx4CMXYuVQSPuILM2DslJ7H/nC0iOF/0T00wdB04t89/1O/w1cDnyilFU=')

# 此處要替串掉 你自己的 ngrok url /callback 不需要覆蓋
line_bot_api.set_webhook_endpoint(f'https://4c7a-115-43-180-171.ngrok-free.app/callback')


@app.route("/callback", methods=['POST', 'GET'])
def linebot():
    body = request.get_data(as_text=True)                    # 取得收到的訊息內容
    try:
      json_data = json.loads(body)
      print(json_data)         
      tk = json_data['events'][0]['replyToken']            # 取得回傳訊息的 Token
      type = json_data['events'][0]['message']['type']     # 取得 LINe 收到的訊息類型
      if type=='text':
          msg = json_data['events'][0]['message']['text']
          ans = pdf_caht.getAnswer(msg)      
          reply = ans
          line_bot_api.reply_message(tk, TextSendMessage(reply))
    except Exception as e:
        print('錯誤')
        print(e)
    return 'OK', 200


app.run(port=5507)